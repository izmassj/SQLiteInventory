public enum Direction
{
    North,
    East,
    West,
    South
}
