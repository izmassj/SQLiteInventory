public enum PlayerState
{
    Idle,
    Moving,
    Turning,
    Menu,
    Bag,
    Dialogue,
    Shop
}