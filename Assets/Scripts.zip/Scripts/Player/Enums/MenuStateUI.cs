public enum MenuStateUI
{
    Pokedex,
    Pokemon,
    Bag,
    User,
    Save,
    Options,
    Back
}