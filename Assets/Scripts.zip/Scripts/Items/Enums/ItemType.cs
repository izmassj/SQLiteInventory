[System.Serializable]
public enum ItemType
{
    Object,
    Healing,
    Pokeball,
    TMHM,
    Berry,
    Card,
    CombatObject,
    KeyItem
}