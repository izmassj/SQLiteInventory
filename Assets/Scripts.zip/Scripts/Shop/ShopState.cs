[System.Serializable]
public enum ShopState
{
    Choice,
    Browsing,
    Quantity
}
