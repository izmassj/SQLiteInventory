[System.Serializable]
public enum BagState
{
    Browsing,
    ActionMenu
}